
import fresh_tomatoes
import media
 #movie details 1
slumdog = media.Movie("SLUM DOG MILLIONAIRE","18-year-old Jamal Malik, an Indian Muslim from the Juhu slum, is a contestant on the Indian version of Who Wants to Be a Millionaire?, and is one question away from the grand prize.",
                  "https://upload.wikimedia.org/wikipedia/en/9/92/Slumdog_Millionaire_poster.png",
                  "https://youtu.be/AIzbwV7on6Q")


#movie details 2
ratatouille=media.Movie("RATATOUILLE","A rat chef in a paris",
                        "https://upload.wikimedia.org/wikipedia/en/5/50/RatatouillePoster.jpg",
                        "https://www.youtube.com/watch?v=c3sBBRxDAqk")
#movie details 3
coco=media.Movie("COCO","A story of a small boy",
                 "https://upload.wikimedia.org/wikipedia/en/d/d7/Coco_%282017_film%29_logo.jpg",
                 "https://www.youtube.com/watch?v=jjudmcSxzpc")

#movie details 4
walk_to_remember=media.Movie("A WALK TO REMEMBER","I cant see it but i can feel it",
                          "https://upload.wikimedia.org/wikipedia/en/d/dc/A_Walk_to_Remember_Poster.jpg",
                          "https://youtu.be/i72wRvPw_ik")

#movie details 5
the_beauty_and_the_beast=media.Movie("THE BEAUTY AND THE BEAST","A chemistry betwween the lady and the beast",
                                     "https://upload.wikimedia.org/wikipedia/en/d/d6/Beauty_and_the_Beast_2017_poster.jpg",
                                     "https://www.youtube.com/watch?v=OvW_L8sTu5E")
#movie details 6
titanic = media.Movie("TITANIC","When Rose boards the Titanic, she meets Jack Dawson, an artist, and falls in love with him.",
                      "https://upload.wikimedia.org/wikipedia/en/2/22/Titanic_poster.jpg",
                      "https://youtu.be/2e-eXJ6HgkQ")
#moie details 7
half_girl_friend=media.Movie("HALF GIRL FRIEND","ndian romantic drama film based on the novel of the same name written by Chetan Bhagat",
                             "http://media1.santabanta.com/full1/Bollywood%20Movies/Half%20Girlfriend/half-girlfriend-2a.jpg",
                             "https://youtu.be/KmlBnmyelHI")
#movie details 8
three_idiots= media.Movie("THREE IDIOTS"," It was inspired by the novel Five Point Someone by Chetan Bhagat.",
                          "https://upload.wikimedia.org/wikipedia/en/d/df/3_idiots_poster.jpg",
                          "https://youtu.be/xvszmNXdM4w")
#movie details 9
dangal = media.Movie("DANGAL","Story of two world class wrestlers..",
                     "https://images-na.ssl-images-amazon.com/images/M/MV5BMTQ4MzQzMzM2Nl5BMl5BanBnXkFtZTgwMTQ1NzU3MDI@._V1_UY268_CR4,0,182,268_AL_.jpg",
                     "https://youtu.be/x_7YlGv9u1g")

movies = [slumdog,ratatouille,coco,walk_to_remember,the_beauty_and_the_beast,titanic,half_girl_friend,three_idiots,dangal]
fresh_tomatoes.open_movies_page(movies)
