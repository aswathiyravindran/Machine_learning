*This is a web based software.*

It directs the users to see the list available movies along with their trailers.

#INSTALLATION
To install the __Movie_Trailer_Website__ files,Just download the zip files
For instruction on installing Python 2.7 Interpreter,
please check out the [Installation mannual]("https://docs.python.org/2/install/index.html")

#EXECUTION
open the terminal. Move to the specified directory where your project folder is situated.
Execute the python file using the syntax given below.
python <file_name>.py
python Entertainment.py
The command prompt display the report message
The new window will be opened in the existing browser.

NOTE:
The entertainment.py class contains the movie details 
